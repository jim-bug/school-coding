/*
* Autore: Ignazio Leonardo Calogero Sperandeo
* Data: 09/02/2025
* Consegna: Realizzare un application server in Java, attraverso tomcat, che dati due parametri dalla URL, mese e anno, restistuica il corrispettivo calendario.
* by jim_bug // :)
*/

package it.java.jimcal;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jim_bug
 */
@WebServlet(name = "JimCal", urlPatterns = {"/cal"})
public class JimCal extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response, String month, String year) throws ServletException, IOException {
        try{
            Date firstDate = new Date(month, year);
            request.setAttribute("firstDate", firstDate.getDate());
            request.getRequestDispatcher("WEB-INF/jsp/calendar.jsp").forward(request, response);
        }
        catch(IllegalArgumentException e){
            request.getRequestDispatcher("WEB-INF/jsp/error.jsp").forward(request, response);       // forward server side.
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String month = request.getParameter("month");
        String year = request.getParameter("year");
        processRequest(request, response, month, year);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String month = request.getParameter("month");
        String year = request.getParameter("year");
        processRequest(request, response, month, year);
    }
}
// :)