/*
* Autore: Ignazio Leonardo Calogero Sperandeo
* Data: 09/02/2025
* Consegna: Realizzare un application server in Java, attraverso tomcat, che dati due parametri dalla URL, mese e anno, restistuica il corrispettivo calendario.
* by jim_bug // :)
*/

package it.java.jimcal;
import java.time.LocalDate;
import java.time.Month;

/**
 * La classe Date si occupa di controllare mese e anno dati via GET o POST.
 * 
 * @see java.time.LocaDate
 * @see java.time.Month
 * @author jim_bug
 */
public class Date {
    // private static String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    private int month;
    private int year;
    private LocalDate date;
    
    public Date(String month, String year){
        setMonth(month);
        setYear(year);
        setDate();
    }
    
    /**
        * Il metodo si occupa di controllare il mese. Se il mese è valido assegna al mese il numero corrispondente (1-12).
        * Nel caso in cui il mese risulti non valido verrà assegnato il valore di -1. Se risulta null assegna il mese corrente.
        * 
        * @see java.lang.Integer
        * @see java.time.Month
        * @see java.lang.NumberFormatException
        * @see java.lang.IllegalArgumentException
        * @see java.lang.NullPointerException
    */
    public void setMonth(String month){
        try{
            this.month = Integer.parseInt(month.trim());
            if(this.month < 1 || this.month > 12){
                this.month = -1;
            }
        }
        catch(NumberFormatException e){
            try{
                this.month = Month.valueOf(month.toUpperCase()).getValue();
            }
            catch(IllegalArgumentException e1){
                this.month = -1;
            }
        }
        catch(NullPointerException e3){
            this.month = LocalDate.now().getMonthValue();
        }
    }
    
    /**
        * Il metodo si occupa di controllare l'anno. Se l'anno è valido assegna all'anno il numero corrispondente.
        * Nel caso in cui l'anno risulti non valido (minore di 1900) verrà assegnato il valore di -1. Se risulta null assegna l'anno corrente.
        * 
        * @see java.lang.Integer
        * @see java.lang.NumberFormatException
        * @see java.lang.NullPointerException
    */
    public void setYear(String year){
        try{
            this.year = Integer.parseInt(year.trim());
            if(this.year < 1900){
                this.year = -1;
            }
        }
        catch(NumberFormatException e){
            this.year = -1;
        }
        catch(NullPointerException e1){
            this.year = LocalDate.now().getYear();
        }
    }
    
    
    /**
        * Il metodo si occupa di costruire l'istanza del primo giorno del mese e anno (dati in input).
        * Se il mese o l'anno sono uguale a -1 il metodo solleverà un eccezione.
        * 
        * @see java.lang.IllegalArgumentException
        * @see java.time.LocaDate
        * @throws IllegalArgumentException
    */
    public void setDate() throws IllegalArgumentException {
        if(this.year == -1 || this.month == -1){
            throw new IllegalArgumentException("Invalid year or month value");
        }
        date = LocalDate.of(this.year, this.month, 1);
    }
    
    public LocalDate getDate(){
        return date;
    }
    
    public int getMonth(){
        return month;
    }
    
    public int getYear(){
        return year;
    }
}
// :)
