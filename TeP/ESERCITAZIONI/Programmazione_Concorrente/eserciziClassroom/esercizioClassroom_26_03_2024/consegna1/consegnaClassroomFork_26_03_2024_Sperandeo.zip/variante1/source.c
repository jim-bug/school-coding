#include <stdio.h>

int main(){
	printf("\nSONO IL CONTENUTO DI SOURCE.C+1\n");
	return 0;
}
