Prima di compilare ed eseguire il programma, assicurarsi di eseguire prima lo script generateFile.sh
