package it.java.gerarchie;

public interface Acquatico {
	public void ormeggia();
	public void accosta();
}
