package it.java.AlberoBinario;

public class Main {

	public static void main(String[] args) {
		AlberoBinarioRicerca albero = new AlberoBinarioRicerca();
		albero.push(81);
		albero.push(4);
		albero.push(2);
		albero.push(5);
		albero.push(50);
		albero.push(49);
		albero.push(80);
		albero.print();

	}

}
