    </head>
    <body>
        <a href="https://github.com/jim-bug"><img class="logo" src="./images/logo.png" alt="Logo" width="50" height="50"></a>
        <h1 align="center">BENVENUTO NELLA COMPILAZIONE DEI FORM DI STUDENTI, LIBRI, PRESTITI</h1>
        <div class="table-container">
            <table border="1">
                <th><a href="show.php?type=studente" class="link">Studenti</a></th>
                <th><a href="show.php?type=corso" class="link">Corsi</a></th>
                <th><a href="show.php?type=facolta" class="link">Facoltà</a></th>
                <th><a href="show.php?type=universita" class="link">Università</a></th>
                <th><a href="show.php?type=libro" class="link">Libri</a></th>
                <th><a href="show.php?type=editrice" class="link">Case editrici</a></th>
                <th><a href="show.php?type=prestito" class="link">Prestiti</a></th>
                <th><a href="show.php?type=frequenza" class="link">Frequenze</a></th>
            </table>
        </div>
        <a href="./index1.php" class="links">Home</a>
        <!-- <a href="<?php echo $_SERVER['HTTP_REFERER'] ?? 'main.php'; // HTTP_REFERER ritorna l'URL della pagina di provenienza.?>" class="links">Back</a> -->