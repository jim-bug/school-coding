    </head>
    <body>
        <a href="https://github.com/jim-bug"><img class="logo" src="./images/logo.png" alt="Logo" width="50" height="50"></a>
        <h1 align="center">BENVENUTO NELLA COMPILAZIONE DEI FORM CLIENTE E AUTO</h1>
        <div class="table-container">
            <table border="1">
                <th><a href="./cliente.php" class="link">Clienti</a></th>
                <th><a href="./auto.php" class="link">Auto</a></th>
            </table>
        </div>
        <a href="./index.php" class="links">Home</a>