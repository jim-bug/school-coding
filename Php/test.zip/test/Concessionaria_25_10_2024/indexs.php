<?php 
    /*
    * Autore: Ignazio Leonardo Calogero Sperandeo
    * Classe: 5C INF
    * Data: 25/10/2024
    * by jim_bug // :)
    */ 
    include "./includes/header.php"; 
?>
    <link rel="stylesheet" href="./css/style_client_car.css">
<?php include "./includes/main.php"; ?>
<?php include "./includes/footer.php"; ?>
